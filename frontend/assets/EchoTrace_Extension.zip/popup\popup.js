// chrome_extension/popup/popup.js

// Laragon serves on port 80. The PHP built-in dev server uses port 8000.
// Users can override this in the extension settings popup.
const DEFAULT_API_URL = "http://localhost/capsatone2/backend/api/index.php";

document.addEventListener('DOMContentLoaded', () => {
    initPopup();
    
    // Bind buttons
    document.getElementById('login-form')?.addEventListener('submit', handleLogin);
    document.getElementById('logout-btn')?.addEventListener('click', handleLogout);
    
    document.getElementById('settings-btn')?.addEventListener('click', () => showPane('settings'));
    document.getElementById('close-settings-btn')?.addEventListener('click', () => loadUserState());
    document.getElementById('save-settings-btn')?.addEventListener('click', saveSettings);
    document.getElementById('close-results-btn')?.addEventListener('click', dismissResults);
    
    // View Full Report button handler
    document.getElementById('results-view-report')?.addEventListener('click', handleViewReportClick);

    // Scan Current Product from Popup handler
    document.getElementById('popup-scan-btn')?.addEventListener('click', handlePopupScanClick);

    // Toggle Flagged Reviews Accordion
    document.getElementById('toggle-flagged-btn')?.addEventListener('click', toggleFlaggedReviews);
});

const handleViewReportClick = (e) => {
    e.preventDefault();
    const reportButton = document.getElementById('results-view-report');
    if (reportButton?.dataset.loading === 'true') return;
    if (reportButton) {
        reportButton.dataset.loading = 'true';
        reportButton.classList.add('is-loading');
        reportButton.textContent = 'Opening dashboard…';
    }
    chrome.storage.local.get(["last_scan_result"], (items) => {
        const scanId = items.last_scan_result?.scan_id || "";

        // Build base frontend URL from api_url — no token in URL
        chrome.runtime.sendMessage({
            action: 'OPEN_FULL_REPORT',
            scan_id: scanId
        }, (response) => {
            if (reportButton) {
                reportButton.dataset.loading = 'false';
                reportButton.classList.remove('is-loading');
            }
            if (chrome.runtime.lastError || !response?.success) {
                console.warn('[EchoTrace] Unable to open dashboard report:', chrome.runtime.lastError?.message || response?.error);
                if (reportButton) reportButton.textContent = 'Unable to open report';
            } else if (reportButton) {
                reportButton.textContent = 'Dashboard opened';
                setTimeout(() => { if (reportButton.isConnected) reportButton.textContent = 'View Full Interactive Report'; }, 1200);
            }
        });
    });
};

const handlePopupScanClick = () => {
    const scanBtn = document.getElementById('popup-scan-btn');
    const scanningProgress = document.getElementById('scanning-progress');
    if (!scanBtn) return;

    const origText = scanBtn.textContent;

    const setScanningUI = (active, statusText) => {
        scanBtn.disabled = active;
        scanBtn.textContent = active ? '⏳ Scanning…' : origText;
        const subEl = document.querySelector('.scanning-sub');
        if (subEl && statusText) subEl.textContent = statusText;
        if (scanningProgress) {
            if (active) scanningProgress.classList.remove('hidden');
            else scanningProgress.classList.add('hidden');
        }
    };

    setScanningUI(true, 'Looking for reviews on this page…');

    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (!tabs || !tabs[0]) {
            setScanningUI(false);
            return;
        }

        const tabId = tabs[0].id;

        // Listen for the completed scan result broadcasted from background
        // This fires AFTER the full ML pipeline finishes, not just on message receipt
        const onScanComplete = (message) => {
            if (message.action === 'SCAN_RESULT' || message.action === 'SCAN_ERROR') {
                chrome.runtime.onMessage.removeListener(onScanComplete);
                setScanningUI(false);
                if (message.action === 'SCAN_ERROR') {
                    const banner = document.getElementById('connection-banner');
                    if (banner) {
                        banner.className = 'status-banner error';
                        banner.textContent = message.error || 'Scan failed. Check backend is running.';
                    }
                }
                // displayScanResults will be triggered by the storage change listener
            }
        };
        chrome.runtime.onMessage.addListener(onScanComplete);

        // Safety timeout — if no response in 30s, stop spinning
        const safetyTimer = setTimeout(() => {
            chrome.runtime.onMessage.removeListener(onScanComplete);
            setScanningUI(false);
            const banner = document.getElementById('connection-banner');
            if (banner) {
                banner.className = 'status-banner error';
                banner.textContent = 'Scan timed out. Make sure the backend is running.';
            }
        }, 45000);

        // Trigger the scan in the content script
        chrome.tabs.sendMessage(tabId, { action: 'TRIGGER_SCAN' }, (response) => {
            if (chrome.runtime.lastError || !response || !response.success) {
                clearTimeout(safetyTimer);
                chrome.runtime.onMessage.removeListener(onScanComplete);
                setScanningUI(false);
                const errMsg = chrome.runtime.lastError
                    ? 'Please refresh the product page and try again.'
                    : (response && response.error ? response.error : 'Could not start scan.');
                const banner = document.getElementById('connection-banner');
                if (banner) {
                    banner.className = 'status-banner error';
                    banner.textContent = errMsg;
                }
                return;
            }
            // Scan is now running — update status text while waiting
            const subEl = document.querySelector('.scanning-sub');
            if (subEl) subEl.textContent = 'Extracting and analyzing reviews with AI…';
        });
    });
};

const initPopup = () => {
    // Load current config and state
    chrome.storage.local.get(["api_url", "auth_token", "username"], (items) => {
        const apiUrl = items.api_url || DEFAULT_API_URL;
        const settingsInput = document.getElementById('settings-api-url');
        if (settingsInput) settingsInput.value = apiUrl;
        
        checkApiHealth(apiUrl);
        loadUserState();
        loadLastScanResult();
    });
};

const checkApiHealth = async (apiUrl) => {
    const banner = document.getElementById('connection-banner');
    if (!banner) return;
    banner.className = "status-banner info";
    banner.textContent = "Checking API status...";

    const healthUrl = `${apiUrl}?route=auth/login`;
    
    try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 4000);

        await fetch(healthUrl, { method: 'OPTIONS', signal: controller.signal });
        clearTimeout(timeoutId);

        banner.className = "status-banner success";
        banner.textContent = "EchoTrace System: Online";
    } catch (err) {
        banner.className = "status-banner error";
        banner.textContent = "EchoTrace System: Offline (Local server stopped)";
        console.error("Health check failed:", err);
    }
};

const loadUserState = () => {
    chrome.storage.local.get(["auth_token", "username"], (items) => {
        const token = items.auth_token;
        const username = items.username;

        if (token && username) {
            const userEl = document.getElementById('user-display-name');
            if (userEl) userEl.textContent = username;
            showPane('dashboard');
        } else {
            showPane('login');
        }
    });
};

const showPane = (paneName) => {
    document.querySelectorAll('.pane').forEach(el => el.classList.add('hidden'));
    const pane = document.getElementById(`status-${paneName}`);
    if (pane) pane.classList.remove('hidden');
};

const handleLogin = async (e) => {
    e.preventDefault();
    const errorEl = document.getElementById('login-error');
    if (errorEl) errorEl.classList.add('hidden');

    const usernameOrEmail = document.getElementById('login-input').value;
    const password = document.getElementById('login-password').value;

    chrome.storage.local.get(["api_url"], async (items) => {
        const apiUrl = items.api_url || DEFAULT_API_URL;
        const loginUrl = `${apiUrl}?route=auth/login`;

        try {
            const response = await fetch(loginUrl, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ username_or_email: usernameOrEmail, password: password })
            });

            const data = await response.json();
            if (response.ok && data.success) {
                chrome.storage.local.set({
                    auth_token: data.token,
                    username: data.user.username,
                    user_id: data.user.id
                }, () => {
                    const form = document.getElementById('login-form');
                    if (form) form.reset();
                    loadUserState();
                });
            } else {
                if (errorEl) {
                    errorEl.textContent = data.error || "Authentication failed.";
                    errorEl.classList.remove('hidden');
                }
            }
        } catch (err) {
            if (errorEl) {
                errorEl.textContent = "Unable to connect to local PHP server.";
                errorEl.classList.remove('hidden');
            }
        }
    });
};

const handleLogout = () => {
    chrome.storage.local.remove(["auth_token", "username", "last_scan_result"], () => {
        console.log('[EchoTrace] User logged out - session cleared');
        loadUserState();
    });
};

const saveSettings = () => {
    const rawUrl = document.getElementById('settings-api-url').value.trim();
    if (!rawUrl) return;

    chrome.storage.local.set({ api_url: rawUrl }, () => {
        alert("Configuration saved successfully.");
        checkApiHealth(rawUrl);
        loadUserState();
    });
};

// ─── SCAN RESULTS DISPLAY ──────────────────────────────────────────────────

const loadLastScanResult = () => {
    chrome.storage.local.get(["last_scan_result"], (items) => {
        if (items.last_scan_result) {
            displayScanResults(items.last_scan_result);
        }
    });
};

const animateValue = (el, start, end, duration = 800) => {
    let startTimestamp = null;
    const step = (timestamp) => {
        if (!startTimestamp) startTimestamp = timestamp;
        const progress = Math.min((timestamp - startTimestamp) / duration, 1);
        const easeOut = 1 - Math.pow(1 - progress, 3);
        const current = Math.floor(easeOut * (end - start) + start);
        el.textContent = `${current}%`;
        if (progress < 1) {
            window.requestAnimationFrame(step);
        } else {
            el.textContent = `${Math.round(end)}%`;
        }
    };
    window.requestAnimationFrame(step);
};

const displayScanResults = (data) => {
    const panel = document.getElementById('scan-results-panel');
    const scanningProgress = document.getElementById('scanning-progress');
    const scoreEl = document.getElementById('results-score-value');
    const circleEl = document.getElementById('results-score-circle');
    const titleEl = document.getElementById('results-product-title');
    const riskBadge = document.getElementById('results-risk-badge');
    const ratingBadge = document.getElementById('results-rating-badge');
    const reviewCount = document.getElementById('results-review-count');
    
    // Ratio bar elements
    const ratioGenuineLabel = document.getElementById('ratio-label-genuine');
    const ratioFakeLabel = document.getElementById('ratio-label-fake');
    const ratioBarGenuine = document.getElementById('ratio-bar-genuine');
    const ratioBarFake = document.getElementById('ratio-bar-fake');

    // Stats Grid
    const statTotal = document.getElementById('stat-total');
    const statGenuine = document.getElementById('stat-genuine');
    const statFake = document.getElementById('stat-fake');

    // Strengths, Weaknesses, Recommendation
    const strengthsUl = document.getElementById('results-strengths');
    const weaknessesUl = document.getElementById('results-weaknesses');
    const recEl = document.getElementById('results-recommendation');
    const reportLink = document.getElementById('results-view-report');

    // Flagged Section
    const flaggedSection = document.getElementById('flagged-reviews-section');
    const flaggedCountLabel = document.getElementById('flagged-count-label');
    const flaggedList = document.getElementById('flagged-reviews-list');

    if (!panel) return;
    if (scanningProgress) scanningProgress.classList.add('hidden');

    const trustScore = parseFloat(data.trust_score || 0);
    if (scoreEl) {
        animateValue(scoreEl, 0, trustScore, 850);
    }

    // Color the score circle
    if (circleEl) {
        circleEl.classList.remove('warn', 'danger');
        if (trustScore < 50) {
            circleEl.classList.add('danger');
        } else if (trustScore < 80) {
            circleEl.classList.add('warn');
        }
    }

    // Product title
    if (titleEl) titleEl.textContent = data.product_title || data.product?.title || 'Product Audit';

    // Risk badge
    const riskLevel = (data.overall_risk_level || (trustScore >= 80 ? 'Low Risk' : (trustScore >= 50 ? 'Moderate Risk' : 'High Risk'))).toUpperCase();
    if (riskBadge) {
        riskBadge.textContent = riskLevel;
        riskBadge.classList.remove('warn', 'danger');
        if (riskLevel.includes('HIGH')) {
            riskBadge.classList.add('danger');
        } else if (riskLevel.includes('MEDIUM') || riskLevel.includes('MODERATE')) {
            riskBadge.classList.add('warn');
        }
    }

    // Rating Comparison Badge
    const avgRating = data.metrics?.average_rating || data.rating || null;
    const adjRating = data.metrics?.adjusted_rating || null;
    if (ratingBadge) {
        if (avgRating !== null && adjRating !== null) {
            ratingBadge.textContent = `⭐ ${parseFloat(avgRating).toFixed(1)} → 🛡️ ${parseFloat(adjRating).toFixed(1)}`;
            ratingBadge.classList.remove('hidden');
        } else {
            ratingBadge.classList.add('hidden');
        }
    }

    // Metrics breakdown
    const total = (data.metrics?.total_scanned) || (data.results?.length) || 0;
    const fake = (data.metrics?.fake_detected) || (data.results ? data.results.filter(r => r.is_fake).length : 0);
    const genuine = (data.metrics?.genuine_detected) || (total - fake);
    
    const genuinePct = total > 0 ? Math.round((genuine / total) * 100) : 100;
    const fakePct = total > 0 ? Math.round((fake / total) * 100) : 0;

    if (reviewCount) {
        reviewCount.textContent = `${total} reviews analyzed • ${fake} suspicious`;
    }

    // Ratio Bar
    if (ratioGenuineLabel) ratioGenuineLabel.textContent = `✅ ${genuinePct}% Genuine (${genuine})`;
    if (ratioFakeLabel) ratioFakeLabel.textContent = `🚨 ${fakePct}% Suspicious (${fake})`;
    if (ratioBarGenuine) ratioBarGenuine.style.width = `${genuinePct}%`;
    if (ratioBarFake) ratioBarFake.style.width = `${fakePct}%`;

    // Stats Grid
    if (statTotal) statTotal.textContent = total;
    if (statGenuine) statGenuine.textContent = genuine;
    if (statFake) statFake.textContent = fake;

    // Strengths
    if (strengthsUl) {
        strengthsUl.innerHTML = '';
        const strengths = data.summary?.strengths || [];
        if (strengths.length > 0) {
            strengths.forEach(s => {
                const li = document.createElement('li');
                li.textContent = s;
                strengthsUl.appendChild(li);
            });
            document.getElementById('section-strengths')?.classList.remove('hidden');
        } else {
            document.getElementById('section-strengths')?.classList.add('hidden');
        }
    }

    // Weaknesses
    if (weaknessesUl) {
        weaknessesUl.innerHTML = '';
        const weaknesses = data.summary?.weaknesses || [];
        if (weaknesses.length > 0) {
            weaknesses.forEach(w => {
                const li = document.createElement('li');
                li.textContent = w;
                weaknessesUl.appendChild(li);
            });
            document.getElementById('section-weaknesses')?.classList.remove('hidden');
        } else {
            document.getElementById('section-weaknesses')?.classList.add('hidden');
        }
    }

    // Recommendation
    if (recEl) {
        recEl.textContent = data.summary?.recommendation || '';
    }

    // Flagged suspicious reviews list
    const fakeReviews = (data.results || []).filter(r => {
        const probability = Number(r.confidence_score);
        return r.is_fake && !(probability >= 40 && probability <= 60);
    });
    if (flaggedSection && flaggedCountLabel && flaggedList) {
        if (fakeReviews.length > 0) {
            flaggedCountLabel.textContent = `⚠️ View Flagged Fake Reviews (${fakeReviews.length})`;
            flaggedSection.classList.remove('hidden');
            
            flaggedList.innerHTML = '';
            fakeReviews.forEach(r => {
                const item = document.createElement('div');
                item.className = 'flagged-item';
                const reasons = (r.fake_reasons && r.fake_reasons.length > 0)
                    ? r.fake_reasons
                    : ['Suspicious pattern'];

                const snippet = r.text.length > 120 ? r.text.substring(0, 120) + '...' : r.text;
                const textEl = document.createElement('div');
                textEl.className = 'flagged-item-text';
                textEl.textContent = `"${snippet}"`;
                const reasonsEl = document.createElement('div');
                reasonsEl.className = 'flagged-item-reasons';
                reasons.forEach(rs => {
                    const tag = document.createElement('span');
                    tag.className = 'flagged-reason-tag';
                    tag.textContent = rs;
                    reasonsEl.appendChild(tag);
                });
                item.appendChild(textEl);
                item.appendChild(reasonsEl);
                flaggedList.appendChild(item);
            });
        } else {
            flaggedSection.classList.add('hidden');
        }
    }

    // Report link display
    if (reportLink) {
        reportLink.classList.remove('hidden');
    }

    panel.classList.remove('hidden');
};

const toggleFlaggedReviews = () => {
    const list = document.getElementById('flagged-reviews-list');
    const arrow = document.getElementById('toggle-flagged-arrow');
    if (!list) return;

    const isHidden = list.classList.contains('hidden');
    if (isHidden) {
        list.classList.remove('hidden');
        if (arrow) arrow.textContent = '▲';
    } else {
        list.classList.add('hidden');
        if (arrow) arrow.textContent = '▼';
    }
};

const dismissResults = () => {
    const panel = document.getElementById('scan-results-panel');
    if (panel) panel.classList.add('hidden');
    chrome.storage.local.remove(["last_scan_result"]);
};

// ─── REALTIME EVENT LISTENERS ───────────────────────────────────────────────

// Listen for direct broadcast messages from background or content script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "SCAN_RESULT") {
        displayScanResults(message.data);
        sendResponse({ received: true });
    }
});

// Listen for storage changes in case scan result was updated by another tab
chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === "local" && changes.last_scan_result?.newValue) {
        displayScanResults(changes.last_scan_result.newValue);
    }
});
